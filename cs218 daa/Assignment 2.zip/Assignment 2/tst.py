# generate_100k_case.py
# Creates 1 simple polygon with 100000 vertices and 0 holes
# Format matches the assignment PDF:
# T
# v0 x1 y1 x2 y2 ... xv0 yv0
# h
# ... hole lines

n = 100000

pts = []

# Make a long x-monotone simple "zig-zag" polygon:
# upper chain left -> right
for i in range(n // 2):
    x = 2 * i
    y = 1000000 + (i % 2)
    pts.append((x, y))

# lower chain right -> left
for i in range(n // 2 - 1, -1, -1):
    x = 2 * i
    y = 0 - (i % 2)
    pts.append((x, y))

# remove duplicate consecutive points if any
clean = [pts[0]]
for p in pts[1:]:
    if p != clean[-1]:
        clean.append(p)

# if odd size mismatch, trim
clean = clean[:n]

print(1)
print(len(clean), end=' ')
for x, y in clean:
    print(x, y, end=' ')
print()
print(0)