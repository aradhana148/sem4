# Assignment 2 - Polygon with Holes Triangulation (Python)

## Files
- `art_gallery_solver.py` - main solver
- `test.sh` - runner script

## Run
```bash
./test.sh < input.txt
```
or
```bash
./test.sh input.txt
```

## What the program does
1. Reads the outer boundary and all holes from the input format in the PDF.
2. Bridges the holes to obtain a simple polygon.
3. Runs `MakeMonotone(P)` using the sweep-line `helper(e)` method.
4. Runs `TriangulateMonotonePolygon(P)` on every y-monotone piece.
5. 3-colors the triangulation and returns one guard set.
6. Generates `triangulation_case_i.png` for every test case.

## Output
For each test case, the program prints:
1. The list of triangles.
2. `GuardBound floor((n+2h)/3)`.
3. `ChosenGuards` and the returned guard locations from the 3-coloring stage.

## Notes
- Outer boundary is normalized to counter-clockwise order.
- Holes are normalized to clockwise order.
- The code keeps the slide names `MakeMonotone` and `TriangulateMonotonePolygon` as aliases.
- A tiny symbolic rotation is applied internally before sweep/triangulation to remove equal-y degeneracies while keeping the reported coordinates unchanged.
