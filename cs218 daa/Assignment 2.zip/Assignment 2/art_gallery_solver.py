import math
import random
import sys
from typing import Dict, List, Optional, Sequence, Set, Tuple

import matplotlib.pyplot as plt

EPS = 1e-9
RNG = random.Random(0)


class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y


def orient(a: Point, b: Point, c: Point) -> float:
    return (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x)


def dist2(a: Point, b: Point) -> float:
    dx = a.x - b.x
    dy = a.y - b.y
    return dx * dx + dy * dy


def polygon_area(poly: Sequence[Point]) -> float:
    area = 0.0
    n = len(poly)
    for i in range(n):
        j = (i + 1) % n
        area += poly[i].x * poly[j].y - poly[j].x * poly[i].y
    return area / 2.0


def ensure_ccw(poly: List[Point]) -> List[Point]:
    if polygon_area(poly) < 0:
        return list(reversed(poly))
    return poly[:]


def ensure_cw(poly: List[Point]) -> List[Point]:
    if polygon_area(poly) > 0:
        return list(reversed(poly))
    return poly[:]


def same_point(a: Point, b: Point) -> bool:
    return abs(a.x - b.x) <= EPS and abs(a.y - b.y) <= EPS


def on_segment(a: Point, b: Point, p: Point) -> bool:
    if abs(orient(a, b, p)) > EPS:
        return False
    return (
        min(a.x, b.x) - EPS <= p.x <= max(a.x, b.x) + EPS and
        min(a.y, b.y) - EPS <= p.y <= max(a.y, b.y) + EPS
    )


def segments_intersect(a: Point, b: Point, c: Point, d: Point) -> bool:
    oa = orient(c, d, a)
    ob = orient(c, d, b)
    oc = orient(a, b, c)
    od = orient(a, b, d)

    if ((oa > EPS and ob < -EPS) or (oa < -EPS and ob > EPS)) and ((oc > EPS and od < -EPS) or (oc < -EPS and od > EPS)):
        return True
    if abs(oa) <= EPS and on_segment(c, d, a):
        return True
    if abs(ob) <= EPS and on_segment(c, d, b):
        return True
    if abs(oc) <= EPS and on_segment(a, b, c):
        return True
    if abs(od) <= EPS and on_segment(a, b, d):
        return True
    return False


def strict_segment_intersection(a: Point, b: Point, c: Point, d: Point) -> bool:
    if not segments_intersect(a, b, c, d):
        return False
    endpoints_ab = [a, b]
    endpoints_cd = [c, d]
    for p in endpoints_ab:
        for q in endpoints_cd:
            if same_point(p, q):
                return False
    # collinear overlap beyond endpoints counts as intersection
    return True

# gauss law
def point_in_simple_polygon(pt: Point, poly: Sequence[Point]) -> bool:
    inside = False
    n = len(poly)
    for i in range(n):
        a = poly[i]
        b = poly[(i + 1) % n]
        if on_segment(a, b, pt):
            return True
        yi = (a.y > pt.y)
        yj = (b.y > pt.y)
        if yi != yj:
            xint = a.x + (pt.y - a.y) * (b.x - a.x) / (b.y - a.y)
            if xint >= pt.x - EPS:
                inside = not inside
    return inside


def point_in_triangle(p: Point, a: Point, b: Point, c: Point) -> bool:
    s1 = orient(a, b, p)
    s2 = orient(b, c, p)
    s3 = orient(c, a, p)
    pos = (s1 >= -EPS and s2 >= -EPS and s3 >= -EPS)
    neg = (s1 <= EPS and s2 <= EPS and s3 <= EPS)
    return pos or neg


def angle_of(u: Point, v: Point) -> float:
    return math.atan2(v.y - u.y, v.x - u.x)


def vertex_above(a: Point, b: Point) -> bool:
    return a.y > b.y + EPS or (abs(a.y - b.y) <= EPS and a.x < b.x - EPS)


def vertex_below(a: Point, b: Point) -> bool:
    return a.y < b.y - EPS or (abs(a.y - b.y) <= EPS and a.x > b.x + EPS)


def edge_intersection_x_at_y(a: Point, b: Point, y: float) -> float:
    if abs(a.y - b.y) <= EPS:
        return min(a.x, b.x)
    t = (y - a.y) / (b.y - a.y)
    return a.x + t * (b.x - a.x)


def normalize_input_polygon(poly: List[Point]) -> List[Point]:
    out = poly[:]
    if len(out) >= 2 and same_point(out[0], out[-1]):
        out.pop()
    return out


def format_number(x: float) -> str:
    if abs(x - round(x)) <= 1e-9:
        return str(int(round(x)))
    s = f"{x:.10f}".rstrip('0').rstrip('.')
    if s == '-0':
        return '0'
    return s


def bridge_visibility(m: Point, p: Point, current_boundary: Sequence[Point], other_holes: Sequence[Sequence[Point]]) -> bool:
    if same_point(m, p):
        return False
    mid = Point((m.x + p.x) / 2.0, (m.y + p.y) / 2.0)
    if not point_in_simple_polygon(mid, current_boundary):
        return False

    n = len(current_boundary)
    for i in range(n):
        a = current_boundary[i]
        b = current_boundary[(i + 1) % n]
        if same_point(a, p) or same_point(b, p):
            continue
        if strict_segment_intersection(m, p, a, b):
            return False

    for hole in other_holes:
        k = len(hole)
        for i in range(k):
            a = hole[i]
            b = hole[(i + 1) % k]
            if same_point(a, m) or same_point(b, m):
                continue
            if strict_segment_intersection(m, p, a, b):
                return False
    return True


def hole_rightmost_vertex(hole: Sequence[Point]) -> int:
    best = 0
    for i in range(1, len(hole)):
        if hole[i].x > hole[best].x + EPS or (
            abs(hole[i].x - hole[best].x) <= EPS and hole[i].y < hole[best].y - EPS
        ):
            best = i
    return best


def choose_bridge_vertex(
    hole: Sequence[Point],
    current_boundary: Sequence[Point],
    remaining_holes: Sequence[Sequence[Point]],
) -> Tuple[int, int]:
    m_idx = hole_rightmost_vertex(hole)
    m = hole[m_idx]

    candidates: List[Tuple[float, float, int]] = []
    for i, p in enumerate(current_boundary):
        if bridge_visibility(m, p, current_boundary, remaining_holes):
            # Prefer a point to the right; then shortest; then lexicographic.
            right_penalty = 0.0 if p.x >= m.x - EPS else 1.0
            candidates.append((right_penalty, dist2(m, p), i))

    if not candidates:
        raise ValueError("Could not find a visible bridge from a hole to the current boundary.")

    candidates.sort(key=lambda t: (t[0], t[1], current_boundary[t[2]].y, current_boundary[t[2]].x))
    return m_idx, candidates[0][2]


def unit_vector(a: Point, b: Point) -> Tuple[float, float]:
    dx = b.x - a.x
    dy = b.y - a.y
    norm = math.hypot(dx, dy)
    if norm <= EPS:
        return (0.0, 0.0)
    return (dx / norm, dy / norm)


def move_along(a: Point, b: Point, delta: float) -> Point:
    ux, uy = unit_vector(a, b)
    return Point(a.x + ux * delta, a.y + uy * delta)


def merge_hole_into_boundary(
    current_boundary_geom: Sequence[Point],
    current_boundary_disp: Sequence[Point],
    hole_geom: Sequence[Point],
    hole_disp: Sequence[Point],
    boundary_idx: int,
    hole_idx: int,
    delta: float,
) -> Tuple[List[Point], List[Point]]:
    outer_g = list(current_boundary_geom)
    outer_d = list(current_boundary_disp)
    hole_g = list(hole_geom)
    hole_d = list(hole_disp)
    m = len(outer_g)
    k = len(hole_g)

    p0g = outer_g[boundary_idx]
    p0d = outer_d[boundary_idx]
    p1g = move_along(p0g, outer_g[(boundary_idx + 1) % m], delta)
    p1d = p0d

    m0g = hole_g[hole_idx]
    m0d = hole_d[hole_idx]
    m1g = move_along(m0g, hole_g[(hole_idx - 1) % k], delta)
    m1d = m0d

    merged_g: List[Point] = [p0g, m0g]
    merged_d: List[Point] = [p0d, m0d]
    for step in range(1, k):
        idx = (hole_idx + step) % k
        merged_g.append(hole_g[idx])
        merged_d.append(hole_d[idx])
    merged_g.append(m1g)
    merged_d.append(m1d)
    merged_g.append(p1g)
    merged_d.append(p1d)
    for step in range(1, m):
        idx = (boundary_idx + step) % m
        merged_g.append(outer_g[idx])
        merged_d.append(outer_d[idx])

    if polygon_area(merged_g) < 0:
        merged_g.reverse()
        merged_d.reverse()
    return merged_g, merged_d


def bridge_holes_into_simple_polygon(
    outer: List[Point],
    holes: List[List[Point]],
) -> Tuple[List[Point], List[Point]]:
    current_boundary_geom = ensure_ccw(normalize_input_polygon(outer))
    current_boundary_disp = current_boundary_geom[:]
    normalized_holes = [ensure_cw(normalize_input_polygon(h)) for h in holes]

    xs = [p.x for p in current_boundary_geom]
    ys = [p.y for p in current_boundary_geom]
    for hole in normalized_holes:
        xs.extend(p.x for p in hole)
        ys.extend(p.y for p in hole)
    scale = max(max(xs) - min(xs), max(ys) - min(ys), 1.0)
    delta = scale * 1e-7

    order = list(range(len(normalized_holes)))
    order.sort(key=lambda idx: max(p.x for p in normalized_holes[idx]), reverse=True)

    remaining: List[List[Point]] = [normalized_holes[idx] for idx in order]
    while remaining:
        hole = remaining.pop(0)
        hole_idx, boundary_idx = choose_bridge_vertex(hole, current_boundary_geom, remaining)
        current_boundary_geom, current_boundary_disp = merge_hole_into_boundary(
            current_boundary_geom,
            current_boundary_disp,
            hole,
            hole,
            boundary_idx,
            hole_idx,
            delta,
        )

    return current_boundary_geom, current_boundary_disp


class TreapNode:
    __slots__ = ('edge_idx', 'prio', 'left', 'right')

    def __init__(self, edge_idx: int):
        self.edge_idx = edge_idx
        self.prio = RNG.random()
        self.left: Optional['TreapNode'] = None
        self.right: Optional['TreapNode'] = None


class SweepLineStatus:
    def __init__(self, poly: Sequence[Point]):
        self.poly = poly
        self.root: Optional[TreapNode] = None
        self.sweep_y = 0.0

    def set_sweep_y(self, y: float) -> None:
        self.sweep_y = y

    def edge_key(self, edge_idx: int) -> Tuple[float, float, float]:
        a = self.poly[edge_idx]
        b = self.poly[(edge_idx + 1) % len(self.poly)]
        x = edge_intersection_x_at_y(a, b, self.sweep_y)
        x2 = edge_intersection_x_at_y(a, b, self.sweep_y - 1e-7)
        return (x, x2, float(edge_idx))

    def less(self, e1: int, e2: int) -> bool:
        return self.edge_key(e1) < self.edge_key(e2)

    def rotate_left(self, x: TreapNode) -> TreapNode:
        y = x.right
        assert y is not None
        x.right = y.left
        y.left = x
        return y

    def rotate_right(self, y: TreapNode) -> TreapNode:
        x = y.left
        assert x is not None
        y.left = x.right
        x.right = y
        return x

    def _insert(self, node: Optional[TreapNode], edge_idx: int) -> TreapNode:
        if node is None:
            return TreapNode(edge_idx)
        if self.less(edge_idx, node.edge_idx):
            node.left = self._insert(node.left, edge_idx)
            if node.left and node.left.prio < node.prio:
                node = self.rotate_right(node)
        elif self.less(node.edge_idx, edge_idx):
            node.right = self._insert(node.right, edge_idx)
            if node.right and node.right.prio < node.prio:
                node = self.rotate_left(node)
        return node

    def insert(self, edge_idx: int) -> None:
        self.root = self._insert(self.root, edge_idx)

    def _delete(self, node: Optional[TreapNode], edge_idx: int) -> Optional[TreapNode]:
        if node is None:
            return None
        if self.less(edge_idx, node.edge_idx):
            node.left = self._delete(node.left, edge_idx)
        elif self.less(node.edge_idx, edge_idx):
            node.right = self._delete(node.right, edge_idx)
        else:
            if node.left is None:
                return node.right
            if node.right is None:
                return node.left
            if node.left.prio < node.right.prio:
                node = self.rotate_right(node)
                node.right = self._delete(node.right, edge_idx)
            else:
                node = self.rotate_left(node)
                node.left = self._delete(node.left, edge_idx)
        return node

    def delete(self, edge_idx: int) -> None:
        self.root = self._delete(self.root, edge_idx)

    def find_left_edge(self, x: float) -> Optional[int]:
        node = self.root
        best: Optional[int] = None
        while node is not None:
            kx = self.edge_key(node.edge_idx)[0]
            if kx < x - EPS:
                best = node.edge_idx
                node = node.right
            else:
                node = node.left
        return best


START = 'start'
END = 'end'
SPLIT = 'split'
MERGE = 'merge'
REGULAR = 'regular'


def vertex_type(poly: Sequence[Point], i: int) -> str:
    n = len(poly)
    prev = poly[(i-1) % n]
    curr = poly[i]
    nxt = poly[(i+1) % n]
    reflex = orient(prev, curr, nxt) < -EPS

    if vertex_below(prev, curr) and vertex_below(nxt, curr):
        return SPLIT if reflex else START

    if vertex_above(prev, curr) and vertex_above(nxt, curr):
        return MERGE if reflex else END

    return REGULAR


def regular_vertex_interior_right(poly: Sequence[Point], i: int) -> bool:
    curr = poly[i]
    nxt = poly[(i + 1) % len(poly)]
    return vertex_below(nxt, curr)


def add_diagonal(diagonals: Set[Tuple[int, int]], u: int, v: int, n: int) -> None:
    if u == v:
        return
    if (u + 1) % n == v or (v + 1) % n == u:
        return
    a, b = sorted((u, v))
    diagonals.add((a, b))

def e_next(i: int) -> int:
    return i

def e_prev(i: int,n:int) -> int:
    return (i - 1) % n

def make_monotone(poly: Sequence[Point]) -> List[Tuple[int, int]]:
    n = len(poly)
    status = SweepLineStatus(poly)
    helper: Dict[int, int] = {}
    diagonals: Set[Tuple[int, int]] = set()
    vtype = [vertex_type(poly, i) for i in range(n)]

    order = list(range(n))
    order.sort(key=lambda i: (-poly[i].y, poly[i].x))


    for i in order:
        status.set_sweep_y(poly[i].y - 1e-7)
        t = vtype[i]

        if t == START:
            status.insert(e_next(i))
            helper[e_next(i)] = i
        elif t == END:
            ep = e_prev(i,n)
            if ep in helper and vtype[helper[ep]] == MERGE:
                add_diagonal(diagonals, i, helper[ep], n)
            status.delete(ep)
            helper.pop(ep, None)
        elif t == SPLIT:
            left = status.find_left_edge(poly[i].x)
            if left is not None:
                add_diagonal(diagonals, i, helper[left], n)
                helper[left] = i
            status.insert(e_next(i))
            helper[e_next(i)] = i
        elif t == MERGE:
            ep = e_prev(i,n)
            if ep in helper and vtype[helper[ep]] == MERGE:
                add_diagonal(diagonals, i, helper[ep], n)
            status.delete(ep)
            helper.pop(ep, None)
            left = status.find_left_edge(poly[i].x)
            if left is not None:
                if vtype[helper[left]] == MERGE:
                    add_diagonal(diagonals, i, helper[left], n)
                helper[left] = i
        else:
            if regular_vertex_interior_right(poly, i):
                ep = e_prev(i,n)
                if ep in helper and vtype[helper[ep]] == MERGE:
                    add_diagonal(diagonals, i, helper[ep], n)
                status.delete(ep)
                helper.pop(ep, None)
                status.insert(e_next(i))
                helper[e_next(i)] = i
            else:
                left = status.find_left_edge(poly[i].x)
                if left is not None:
                    if vtype[helper[left]] == MERGE:
                        add_diagonal(diagonals, i, helper[left], n)
                    helper[left] = i

    return sorted(diagonals)


def unique_face_cycles(faces: Sequence[List[int]]) -> List[List[int]]:
    seen: Set[Tuple[int, ...]] = set()
    result: List[List[int]] = []
    for face in faces:
        m = len(face)
        best = None
        for shift in range(m):
            cyc = tuple(face[shift:] + face[:shift])
            if best is None or cyc < best:
                best = cyc
        assert best is not None
        if best not in seen:
            seen.add(best)
            result.append(list(best))
    return result


def monotone_chains(poly_indices: List[int], points: Sequence[Point]) -> Tuple[List[int], Dict[int, str]]:
    m = len(poly_indices)
    top_pos = min(range(m), key=lambda t: (-points[poly_indices[t]].y, points[poly_indices[t]].x))
    bottom_pos = min(range(m), key=lambda t: (points[poly_indices[t]].y, -points[poly_indices[t]].x))

    chain1: List[int] = []
    i = top_pos
    while True:
        chain1.append(poly_indices[i])
        if i == bottom_pos:
            break
        i = (i + 1) % m

    chain2: List[int] = []
    i = top_pos
    while True:
        chain2.append(poly_indices[i])
        if i == bottom_pos:
            break
        i = (i - 1 + m) % m

    def first_below(chain: List[int]) -> Point:
        return points[chain[1]] if len(chain) > 1 else points[chain[0]]

    p1 = first_below(chain1)
    p2 = first_below(chain2)
    if p1.x < p2.x - EPS:
        left_chain, right_chain = chain1, chain2
    else:
        left_chain, right_chain = chain2, chain1

    label: Dict[int, str] = {}
    for v in left_chain:
        label[v] = 'left'
    for v in right_chain:
        label[v] = 'right'
    label[left_chain[0]] = 'both'
    label[left_chain[-1]] = 'both'
    return sorted(poly_indices, key=lambda idx: (-points[idx].y, points[idx].x)), label


def triangulate_monotone_polygon(poly_indices: List[int], points: Sequence[Point]) -> List[Tuple[int, int]]:
    if len(poly_indices) <= 3:
        return []
    order, chain = monotone_chains(poly_indices, points)
    stack: List[int] = [order[0], order[1]]
    diagonals: List[Tuple[int, int]] = []

    def effective_chain(v: int) -> str:
        return chain[v]

    for j in range(2, len(order) - 1):
        curr = order[j]
        curr_chain = effective_chain(curr)
        top_chain = effective_chain(stack[-1])
        different_chain = (curr_chain != top_chain) and curr_chain != 'both' and top_chain != 'both'
        if different_chain:
            while len(stack) > 1:
                diagonals.append(tuple(sorted((curr, stack[-1]))))
                stack.pop()
            stack.pop()
            stack = [order[j - 1], curr]
        else:
            last = stack.pop()
            while stack:
                top = stack[-1]
                val = orient(points[curr], points[last], points[top])
                if curr_chain == 'left' or (curr_chain == 'both' and chain[last] == 'left'):
                    ok = val < -EPS
                else:
                    ok = val > EPS
                if not ok:
                    break
                diagonals.append(tuple(sorted((curr, top))))
                last = stack.pop()
            stack.append(last)
            stack.append(curr)

    last_vertex = order[-1]
    stack.pop()
    while len(stack) > 1:
        diagonals.append(tuple(sorted((last_vertex, stack[-1]))))
        stack.pop()

    out: List[Tuple[int, int]] = []
    seen: Set[Tuple[int, int]] = set()
    face_set = set(poly_indices)
    for a, b in diagonals:
        if a != b and (a, b) not in seen and a in face_set and b in face_set:
            seen.add((a, b))
            out.append((a, b))
    return out


def split_cycle_by_diagonal(cycle: List[int], u: int, v: int) -> Optional[Tuple[List[int], List[int]]]:
    if u not in cycle or v not in cycle:
        return None
    pu = cycle.index(u)
    pv = cycle.index(v)
    m = len(cycle)
    if (pu + 1) % m == pv or (pv + 1) % m == pu:
        return None
    if pu < pv:
        part1 = cycle[pu:pv + 1]
        part2 = cycle[pv:] + cycle[:pu + 1]
    else:
        part1 = cycle[pu:] + cycle[:pv + 1]
        part2 = cycle[pv:pu + 1]
    return part1, part2


def partition_polygon_by_diagonals(cycle: List[int], diagonals: Sequence[Tuple[int, int]]) -> List[List[int]]:
    pieces: List[List[int]] = [cycle[:]]
    for u, v in diagonals:
        updated = False
        for i, piece in enumerate(pieces):
            parts = split_cycle_by_diagonal(piece, u, v)
            if parts is None:
                continue
            a, b = parts
            pieces = pieces[:i] + [a, b] + pieces[i + 1:]
            updated = True
            break
        if not updated:
            # diagonal may already lie inside a smaller split piece if input contains duplicates;
            # ignore silently only if it became boundary in every current piece.
            pass
    return pieces


def triangle_adjacency(triangles: Sequence[Tuple[int, int, int]]) -> List[List[int]]:
    edge_to_tris: Dict[Tuple[int, int], List[int]] = {}
    for idx, tri in enumerate(triangles):
        a, b, c = tri
        for e in [(a, b), (b, c), (a, c)]:
            edge_to_tris.setdefault(tuple(sorted(e)), []).append(idx)
    adj = [[] for _ in triangles]
    for tris in edge_to_tris.values():
        if len(tris) == 2:
            u, v = tris
            adj[u].append(v)
            adj[v].append(u)
    return adj


def color_triangulation(num_vertices: int, triangles: Sequence[Tuple[int, int, int]]) -> List[int]:
    colors = [-1] * num_vertices
    if not triangles:
        return colors
    adj = triangle_adjacency(triangles)
    stack = [0]
    visited = [False] * len(triangles)
    a, b, c = triangles[0]
    colors[a], colors[b], colors[c] = 0, 1, 2

    while stack:
        t = stack.pop()
        if visited[t]:
            continue
        visited[t] = True
        tri = triangles[t]
        tri_set = set(tri)
        for nb in adj[t]:
            if visited[nb]:
                continue
            other = triangles[nb]
            common = list(tri_set.intersection(other))
            if len(common) != 2:
                continue
            third = next(v for v in other if v not in common)
            used = {colors[common[0]], colors[common[1]]}
            for col in range(3):
                if col not in used:
                    colors[third] = col
                    break
            stack.append(nb)

    for tri in triangles:
        cols = [colors[v] for v in tri]
        missing = [c for c in range(3) if c not in cols]
        uncolored = [v for v in tri if colors[v] == -1]
        for v in uncolored:
            for c in range(3):
                if c not in {colors[u] for u in tri if u != v}:
                    colors[v] = c
                    break
        if len(set(colors[v] for v in tri)) < 3:
            available = [0, 1, 2]
            for v in tri:
                used = {colors[u] for u in tri if u != v and colors[u] != -1}
                for c in available:
                    if c not in used:
                        colors[v] = c
                        break

    for i in range(num_vertices):
        if colors[i] == -1:
            colors[i] = 0
    return colors



def ear_clip_triangulation(poly: Sequence[Point]) -> List[Tuple[int, int, int]]:
    idx = list(range(len(poly)))
    triangles: List[Tuple[int, int, int]] = []
    guard = 0
    while len(idx) > 3 and guard < 10 * len(poly):
        m = len(idx)
        clipped = False
        for i in range(m):
            a = idx[(i - 1) % m]
            b = idx[i]
            c = idx[(i + 1) % m]
            if orient(poly[a], poly[b], poly[c]) <= EPS:
                continue
            ear_ok = True
            for v in idx:
                if v in (a, b, c):
                    continue
                if point_in_triangle(poly[v], poly[a], poly[b], poly[c]):
                    ear_ok = False
                    break
            if ear_ok:
                triangles.append((a, b, c))
                idx.pop(i)
                clipped = True
                break
        if not clipped:
            break
        guard += 1
    if len(idx) == 3:
        triangles.append((idx[0], idx[1], idx[2]))
    return triangles


def triangulate_gallery(outer: List[Point], holes: List[List[Point]]):
    simple_polygon, display_polygon = bridge_holes_into_simple_polygon(outer, holes)
    num_vertices = len(simple_polygon)

    monotone_diagonals = make_monotone(simple_polygon)
    monotone_faces = partition_polygon_by_diagonals(list(range(num_vertices)), monotone_diagonals)

    triangulation_diagonals: Set[Tuple[int, int]] = set()
    for face in monotone_faces:
        for e in triangulate_monotone_polygon(face, simple_polygon):
            triangulation_diagonals.add(tuple(sorted(e)))

    all_diagonals = sorted(set(monotone_diagonals).union(triangulation_diagonals))
    final_faces = partition_polygon_by_diagonals(list(range(num_vertices)), all_diagonals)
    triangles = [tuple(face) for face in final_faces if len(face) == 3]

    if len(triangles) != num_vertices - 2:
        raise RuntimeError("Triangulation failed")

    colors = color_triangulation(num_vertices, triangles)

    color_classes = {0: [], 1: [], 2: []}
    for idx, col in enumerate(colors):
        if col not in color_classes:
            color_classes[col] = []
        color_classes[col].append(idx)
    best_class = min(color_classes.values(), key=len)

    guard_points: List[Point] = []
    seen_coords: Set[Tuple[float, float]] = set()
    for idx in best_class:
        pt = display_polygon[idx]
        key = (round(pt.x, 10), round(pt.y, 10))
        if key not in seen_coords:
            seen_coords.add(key)
            guard_points.append(pt)

    theoretical_bound = (len(outer) + sum(len(h) for h in holes) + 2 * len(holes)) // 3

    final_edges: Set[Tuple[int, int]] = set()
    for i in range(num_vertices):
        final_edges.add(tuple(sorted((i, (i + 1) % num_vertices))))
    for e in all_diagonals:
        final_edges.add(tuple(sorted(e)))

    return {
        'simple_polygon': simple_polygon,
        'display_polygon': display_polygon,
        'monotone_diagonals': monotone_diagonals,
        'triangulation_diagonals': sorted(triangulation_diagonals),
        'triangles': triangles,
        'colors': colors,
        'guard_points': guard_points,
        'theoretical_bound': theoretical_bound,
        'final_edges': final_edges,
    }


# Slide/PDF naming aliases.
def MakeMonotone(P: Sequence[Point]) -> List[Tuple[int, int]]:
    return make_monotone(P)


def TriangulateMonotonePolygon(poly_indices: List[int], points: Sequence[Point]) -> List[Tuple[int, int]]:
    return triangulate_monotone_polygon(poly_indices, points)


def plot_gallery(
    testcase_id: int,
    outer: Sequence[Point],
    holes: Sequence[Sequence[Point]],
    simple_polygon: Sequence[Point],
    triangles: Sequence[Tuple[int, int, int]],
    guard_points: Sequence[Point],
    out_path: str,
) -> None:
    fig, ax = plt.subplots(figsize=(8, 8))

    ox = [p.x for p in outer] + [outer[0].x]
    oy = [p.y for p in outer] + [outer[0].y]
    ax.plot(ox, oy, linewidth=2)

    for hole in holes:
        hx = [p.x for p in hole] + [hole[0].x]
        hy = [p.y for p in hole] + [hole[0].y]
        ax.plot(hx, hy, linewidth=2)

    for a, b, c in triangles:
        tri = [simple_polygon[a], simple_polygon[b], simple_polygon[c], simple_polygon[a]]
        ax.plot([p.x for p in tri], [p.y for p in tri], linewidth=1)

    if guard_points:
        ax.scatter([p.x for p in guard_points], [p.y for p in guard_points], s=60, marker='o')

    ax.set_title(f"Test case {testcase_id}: polygon with holes and triangulation")
    ax.set_aspect('equal', adjustable='box')
    ax.grid(True, alpha=0.25)
    fig.tight_layout()
    fig.savefig(out_path, dpi=200)
    plt.close(fig)


def read_testcases(tokens: List[str]):
    idx = 0

    def nxt(label: str) -> str:
        nonlocal idx
        if idx >= len(tokens):
            raise ValueError(f"Input ended early while reading {label} at token index {idx}")
        val = tokens[idx]
        idx += 1
        return val

    t = int(nxt("T"))
    tests = []

    for tc in range(1, t + 1):
        v0 = int(nxt(f"v0 of testcase {tc}"))
        outer = []
        for j in range(v0):
            x = float(nxt(f"outer vertex {j} x of testcase {tc}"))
            y = float(nxt(f"outer vertex {j} y of testcase {tc}"))
            outer.append(Point(x, y))

        h = int(nxt(f"h of testcase {tc}"))
        holes = []

        for hi in range(1, h + 1):
            vi = int(nxt(f"v{hi} of hole {hi} in testcase {tc}"))
            hole = []
            for j in range(vi):
                x = float(nxt(f"hole {hi} vertex {j} x of testcase {tc}"))
                y = float(nxt(f"hole {hi} vertex {j} y of testcase {tc}"))
                hole.append(Point(x, y))
            holes.append(hole)

        tests.append((outer, holes))

    if idx != len(tokens):
        print(f"Warning: {len(tokens) - idx} extra tokens at end of input")

    return tests


def solve(stdin: str) -> str:
    tokens = stdin.strip().split()
    if not tokens:
        return ''
    tests = read_testcases(tokens)
    output_lines: List[str] = []

    for tc_id, (outer, holes) in enumerate(tests, start=1):
        result = triangulate_gallery(outer, holes)
        triangles = result['triangles']
        guard_points = result['guard_points']
        bound = result['theoretical_bound']

        output_lines.append(f"Case {tc_id}:")
        output_lines.append("Triangles:")
        for tri in triangles:
            pts = [result['display_polygon'][idx] for idx in tri]
            output_lines.append(
                " ".join(f"({format_number(p.x)},{format_number(p.y)})" for p in pts)
            )

        output_lines.append(f"GuardBound {bound}")
        output_lines.append(f"Guards {len(guard_points)}")
        if guard_points:
            output_lines.append(
                " ".join(f"({format_number(p.x)},{format_number(p.y)})" for p in guard_points)
            )
        else:
            output_lines.append("")

        plot_gallery(
            testcase_id=tc_id,
            outer=outer,
            holes=holes,
            simple_polygon=result['simple_polygon'],
            triangles=triangles,
            guard_points=guard_points,
            out_path=f"plots/triangulation_case_{tc_id}.png",
        )

    return "\n".join(output_lines)


def main() -> None:
    data = sys.stdin.read()
    sys.stdout.write(solve(data))

# def main() -> None:
#     data = sys.stdin.read()
#     tokens = data.strip().split()
#     if not tokens:
#         print("No input provided.")
#         return

#     tests = read_testcases(tokens)

#     def face_points(face, poly):
#         return [poly[i] for i in face]

#     def face_area(face, poly):
#         return abs(polygon_area(face_points(face, poly)))

#     def total_face_area(faces, poly):
#         return sum(face_area(face, poly) for face in faces)

#     def is_simple_face(face, poly):
#         pts = face_points(face, poly)
#         m = len(pts)
#         if m < 3:
#             return False
#         for i in range(m):
#             a = pts[i]
#             b = pts[(i + 1) % m]
#             for j in range(i + 1, m):
#                 # skip adjacent edges and same edge
#                 if j == i:
#                     continue
#                 if (j + 1) % m == i or (i + 1) % m == j:
#                     continue
#                 c = pts[j]
#                 d = pts[(j + 1) % m]
#                 if strict_segment_intersection(a, b, c, d):
#                     return False
#         return True

#     def is_polygon_edge(u, v, n):
#         return (u + 1) % n == v or (v + 1) % n == u

#     def diagonal_inside_polygon(poly, u, v):
#         n = len(poly)
#         if u == v or is_polygon_edge(u, v, n):
#             return False
#         a, b = poly[u], poly[v]

#         for i in range(n):
#             j = (i + 1) % n
#             # shared endpoint with polygon edge is okay
#             if i in (u, v) or j in (u, v):
#                 continue
#             if strict_segment_intersection(a, b, poly[i], poly[j]):
#                 return False

#         mid = Point((a.x + b.x) / 2.0, (a.y + b.y) / 2.0)
#         return point_in_simple_polygon(mid, poly)

#     def diagonals_pairwise_noncrossing(diags, poly):
#         for i in range(len(diags)):
#             u1, v1 = diags[i]
#             a, b = poly[u1], poly[v1]
#             for j in range(i + 1, len(diags)):
#                 u2, v2 = diags[j]
#                 if len({u1, v1, u2, v2}) < 4:
#                     continue
#                 c, d = poly[u2], poly[v2]
#                 if strict_segment_intersection(a, b, c, d):
#                     return False, (diags[i], diags[j])
#         return True, None

#     def extract_diagonals_from_triangles(triangles, n):
#         cnt = {}
#         for tri in triangles:
#             a, b, c = tri
#             for e in [tuple(sorted((a, b))), tuple(sorted((b, c))), tuple(sorted((a, c)))]:
#                 cnt[e] = cnt.get(e, 0) + 1
#         out = []
#         for e, k in cnt.items():
#             u, v = e
#             if not is_polygon_edge(u, v, n):
#                 out.append(e)
#         out.sort()
#         return out

#     def is_y_monotone(face, poly):
#         m = len(face)
#         if m < 3:
#             return False

#         # unique top and bottom by the same ordering style used in your code
#         top_pos = min(range(m), key=lambda t: (-poly[face[t]].y, poly[face[t]].x))
#         bot_pos = min(range(m), key=lambda t: (poly[face[t]].y, -poly[face[t]].x))

#         chain1 = []
#         i = top_pos
#         while True:
#             chain1.append(face[i])
#             if i == bot_pos:
#                 break
#             i = (i + 1) % m

#         chain2 = []
#         i = top_pos
#         while True:
#             chain2.append(face[i])
#             if i == bot_pos:
#                 break
#             i = (i - 1 + m) % m

#         def nonincreasing_y(chain):
#             for i in range(len(chain) - 1):
#                 y1 = poly[chain[i]].y
#                 y2 = poly[chain[i + 1]].y
#                 if y2 > y1 + EPS:
#                     return False
#             return True

#         return nonincreasing_y(chain1) and nonincreasing_y(chain2)

#     for tc_id, (outer, holes) in enumerate(tests, start=1):
#         print("=" * 80)
#         print(f"TEST CASE {tc_id}")

#         simple_polygon, display_polygon = bridge_holes_into_simple_polygon(outer, holes)
#         n = len(simple_polygon)
#         poly_area = abs(polygon_area(simple_polygon))

#         print(f"Bridged simple polygon vertex count = {n}")
#         print(f"Bridged simple polygon area        = {poly_area:.10f}")

#         # ------------------------------------------------------------------
#         # 1) Ear clipping baseline
#         # ------------------------------------------------------------------
#         ear_tris = ear_clip_triangulation(simple_polygon)
#         ear_ok = (len(ear_tris) == n - 2)
#         ear_area = sum(abs(polygon_area([simple_polygon[a], simple_polygon[b], simple_polygon[c]]))
#                        for a, b, c in ear_tris)

#         print("\n[1] Ear clipping baseline")
#         print(f"triangles count = {len(ear_tris)} (expected {n - 2})")
#         print(f"area sum        = {ear_area:.10f}")
#         print(f"area diff       = {abs(ear_area - poly_area):.10f}")

#         if not ear_ok or abs(ear_area - poly_area) > 1e-6:
#             print("FAIL: Even ear clipping baseline is not matching. Then the bridged simple polygon is not trustworthy.")
#             continue
#         else:
#             print("PASS: Bridged simple polygon is good enough for debugging downstream.")

#         # ------------------------------------------------------------------
#         # 2) Test partition_polygon_by_diagonals independently
#         # ------------------------------------------------------------------
#         print("\n[2] Testing partition_polygon_by_diagonals using ear-clip diagonals")
#         ear_diags = extract_diagonals_from_triangles(ear_tris, n)
#         print(f"ear diagonals count = {len(ear_diags)} (expected {max(0, n - 3)})")

#         try:
#             faces_from_ear = partition_polygon_by_diagonals(list(range(n)), ear_diags)
#             ear_part_area = total_face_area(faces_from_ear, simple_polygon)
#             num_tri_faces = sum(1 for f in faces_from_ear if len(f) == 3)
#             bad_simple = [idx for idx, f in enumerate(faces_from_ear) if not is_simple_face(f, simple_polygon)]

#             print(f"partitioned faces count       = {len(faces_from_ear)}")
#             print(f"triangle faces count          = {num_tri_faces} (expected {n - 2})")
#             print(f"partition area sum            = {ear_part_area:.10f}")
#             print(f"partition area diff           = {abs(ear_part_area - poly_area):.10f}")
#             print(f"non-simple faces after split  = {len(bad_simple)}")

#             if num_tri_faces != n - 2 or abs(ear_part_area - poly_area) > 1e-6 or bad_simple:
#                 print("FAIL: partition_polygon_by_diagonals is wrong.")
#                 if bad_simple:
#                     print(f"Example bad face index: {bad_simple[0]}")
#                     print("Face vertex indices:", faces_from_ear[bad_simple[0]])
#                 continue
#             else:
#                 print("PASS: partition_polygon_by_diagonals works on known-good diagonals.")
#         except Exception as e:
#             print("FAIL: partition_polygon_by_diagonals raised exception on known-good ear diagonals.")
#             print("Exception:", repr(e))
#             continue

#         # ------------------------------------------------------------------
#         # 3) Test make_monotone
#         # ------------------------------------------------------------------
#         print("\n[3] Testing make_monotone")
#         mono_diags = make_monotone(simple_polygon)
#         print(f"monotone diagonals count = {len(mono_diags)}")

#         bad_diag = None
#         for d in mono_diags:
#             u, v = d
#             if not diagonal_inside_polygon(simple_polygon, u, v):
#                 bad_diag = d
#                 break

#         cross_ok, cross_pair = diagonals_pairwise_noncrossing(mono_diags, simple_polygon)

#         print(f"all monotone diagonals valid internal diagonals? {'YES' if bad_diag is None else 'NO'}")
#         if bad_diag is not None:
#             print("Example invalid monotone diagonal:", bad_diag)

#         print(f"monotone diagonals pairwise noncrossing? {'YES' if cross_ok else 'NO'}")
#         if not cross_ok:
#             print("Crossing pair:", cross_pair)

#         try:
#             mono_faces = partition_polygon_by_diagonals(list(range(n)), mono_diags)
#             mono_area = total_face_area(mono_faces, simple_polygon)
#             bad_simple = [idx for idx, f in enumerate(mono_faces) if not is_simple_face(f, simple_polygon)]
#             bad_mono = [idx for idx, f in enumerate(mono_faces) if not is_y_monotone(f, simple_polygon)]

#             print(f"monotone faces count         = {len(mono_faces)}")
#             print(f"monotone partition area sum  = {mono_area:.10f}")
#             print(f"monotone partition area diff = {abs(mono_area - poly_area):.10f}")
#             print(f"non-simple monotone faces    = {len(bad_simple)}")
#             print(f"non-y-monotone faces         = {len(bad_mono)}")

#             if bad_diag is not None or not cross_ok:
#                 print("FAIL: make_monotone produced bad diagonals.")
#                 continue

#             if abs(mono_area - poly_area) > 1e-6 or bad_simple:
#                 print("FAIL: make_monotone diagonals may be okay, but partition result is invalid.")
#                 continue

#             if bad_mono:
#                 print("FAIL: make_monotone did not actually produce y-monotone pieces.")
#                 print("Example bad face:", mono_faces[bad_mono[0]])
#                 continue

#             print("PASS: make_monotone seems okay.")
#         except Exception as e:
#             print("FAIL: Exception while partitioning using make_monotone diagonals.")
#             print("Exception:", repr(e))
#             continue

#         # ------------------------------------------------------------------
#         # 4) Test triangulate_monotone_polygon independently on each monotone face
#         # ------------------------------------------------------------------
#         print("\n[4] Testing triangulate_monotone_polygon on each monotone face")
#         tri_fail = False
#         for face_id, face in enumerate(mono_faces):
#             m = len(face)
#             expected_diag_count = max(0, m - 3)
#             expected_tri_count = max(1, m - 2) if m >= 3 else 0

#             face_diags = triangulate_monotone_polygon(face, simple_polygon)

#             # basic diagonal validity inside the face polygon
#             face_bad_diag = None
#             face_set = set(face)
#             for d in face_diags:
#                 u, v = d
#                 if u not in face_set or v not in face_set:
#                     face_bad_diag = ("endpoint_not_in_face", d)
#                     break

#             try:
#                 tri_faces = partition_polygon_by_diagonals(face[:], face_diags)
#             except Exception as e:
#                 print(f"FAIL: Face {face_id}: partition after triangulate_monotone_polygon crashed.")
#                 print("Face:", face)
#                 print("Diagonals:", face_diags)
#                 print("Exception:", repr(e))
#                 tri_fail = True
#                 break

#             tri_area = total_face_area(tri_faces, simple_polygon)
#             tri_count = sum(1 for f in tri_faces if len(f) == 3)
#             tri_bad_simple = [idx for idx, f in enumerate(tri_faces) if not is_simple_face(f, simple_polygon)]

#             print(f"Face {face_id}: size={m}, expected diags={expected_diag_count}, got={len(face_diags)}, expected tris={expected_tri_count}, got tris={tri_count}, area diff={abs(tri_area - face_area(face, simple_polygon)):.10f}")

#             if face_bad_diag is not None:
#                 print(f"FAIL: Face {face_id}: triangulate_monotone_polygon produced invalid face diagonal {face_bad_diag}")
#                 tri_fail = True
#                 break

#             if len(face_diags) != expected_diag_count:
#                 print(f"FAIL: Face {face_id}: wrong number of diagonals from triangulate_monotone_polygon.")
#                 print("Face:", face)
#                 print("Returned diagonals:", face_diags)
#                 tri_fail = True
#                 break

#             if tri_count != expected_tri_count:
#                 print(f"FAIL: Face {face_id}: wrong number of triangles after partition.")
#                 print("Face:", face)
#                 print("Returned diagonals:", face_diags)
#                 print("Partitioned pieces:", tri_faces)
#                 tri_fail = True
#                 break

#             if abs(tri_area - face_area(face, simple_polygon)) > 1e-6 or tri_bad_simple:
#                 print(f"FAIL: Face {face_id}: triangulation does not preserve face geometry.")
#                 print("Face:", face)
#                 print("Returned diagonals:", face_diags)
#                 if tri_bad_simple:
#                     print("Example bad triangle/piece:", tri_faces[tri_bad_simple[0]])
#                 tri_fail = True
#                 break

#         if tri_fail:
#             continue

#         print("PASS: triangulate_monotone_polygon seems okay on all monotone faces.")

#         # ------------------------------------------------------------------
#         # 5) Full pipeline summary
#         # ------------------------------------------------------------------
#         print("\n[5] Full pipeline")
#         triangulation_diagonals: Set[Tuple[int, int]] = set()
#         for face in mono_faces:
#             for e in triangulate_monotone_polygon(face, simple_polygon):
#                 triangulation_diagonals.add(tuple(sorted(e)))

#         all_diagonals = sorted(set(mono_diags).union(triangulation_diagonals))
#         final_faces = partition_polygon_by_diagonals(list(range(n)), all_diagonals)
#         triangles = [tuple(face) for face in final_faces if len(face) == 3]
#         final_area = total_face_area(final_faces, simple_polygon)

#         print(f"final triangles count = {len(triangles)} (expected {n - 2})")
#         print(f"final area diff       = {abs(final_area - poly_area):.10f}")

#         if len(triangles) == n - 2 and abs(final_area - poly_area) <= 1e-6:
#             print("PASS: Full monotone pipeline succeeded on this testcase.")
#         else:
#             print("FAIL: Individual parts looked okay, but full pipeline still failed.")
#             print("This usually means diagonal insertion order / duplicate-occurrence handling inside partition_polygon_by_diagonals is the issue.")

if __name__ == '__main__':
    main()